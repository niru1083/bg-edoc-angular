import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  word: any;
  id:string | null = "";

  constructor(private api: ApiService, private router: Router) {
  }

  ngOnInit(): void {
    if(this.id != "0")
    {
      let apiurl = "admin/get";
      let data = this.api.post(apiurl, { data: { id: this.id } });
      data.subscribe((mydata: any) => {
        this.word = mydata.data;
        this.show();
      });
    }
    this.show();
  }

  show = ()=>{
    this.word = new FormGroup({
      id: new FormControl(this.word == null ? "" : this.word._id),
      name: new FormControl(this.word == null ? "" : this.word.keyword, Validators.compose([Validators.required])),
      passwoed: new FormControl(this.word == null ? "" : this.word.replacewith, Validators.compose([Validators.required]))
    });
  }

  submit = (word: any) => {
    let apiurl = "admin/save";
    let data = this.api.post(apiurl, { data: word });
    data.subscribe((mydata: any) => {
      this.router.navigate(["admin/words"]);
    });
  }
}

