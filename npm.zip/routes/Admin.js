var express = require("express");
var body =require("body-parser");
const admins = require("../moduls/admin");
const routes = express.Router();

var jsonparser =body.json();

routes.post("/save",async (req,res)=>{
    let body=req.body;
    console.log(body);
    let words =new admins();
    if (body.data.id != "") {
       words= await admins.findByIdAndUpdate(body.data.id);
    }
    
    words.id = body.data.id;
    words.name = body.data.name;
    words.password = body.data.password;
    words.save().then(result => {
        res.end(JSON.stringify(result));
    }, err => {
        res.end(JSON.stringify(err));
    });
   

})
routes.post("/list",async (req,res)=>{
    let admin = await admins.find()
    res.json({data:admin})
})
routes.post("/get",async (req,res)=>{
    let body=req.body;
    let admin = await admins.findById(body.data.id);
    res.json({data:admin})
})
routes.post("/save",async (req,res)=>{
    let body=req.body;
    let admin = await admins.findByIdAndDelete(body.data.id);
    let data ={
        "data":
        {
            "status":"success"
        }
    }
    res.data(JSON.stringify(data));
});
module.exports = routes;
