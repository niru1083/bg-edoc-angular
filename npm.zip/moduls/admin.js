const mongoose =require("mongoose");
const Schema = mongoose.Schema;

const schema = new Schema(
    {
        id : {type:String},
        name : {type:String},
        password : {type:String},
    }
);
const admins = mongoose.model("admin",schema);
module.exports =admins;