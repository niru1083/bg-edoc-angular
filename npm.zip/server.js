var express =require("express");
var body =require("body-parser");
var multer =require("multer");
var mongoose =require("mongoose");
var app = express();


mongoose.connect('mongodb://logcalhost:27017/empdata');
const db = mongoose.connection;
db.on("error",error => console.log(error));
db.on("open",()=>console.log("connection is good"));

app.listen(8081,function(){
    console.log("server running")
});
app.get("/",function(req,res){
    res.send("hello")
});

app.use("/admin", require("./routes/admin"));